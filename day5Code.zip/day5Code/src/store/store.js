import { combineReducers } from "redux";
import {createStore} from "redux";
import {cartReducer} from "./reducer/cartReducer";
import { userReducer } from "./reducer/userReducer";

var myReducer=combineReducers({
    cart:cartReducer,
    user:userReducer
})
export var store=createStore(myReducer);