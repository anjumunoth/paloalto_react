import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
    <App />
 
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
 

/* import {createStore,combineReducers} from "redux";
function userReducer(state={userArr:[]},action)
{
    console.log("Inside userReducer");
    var newState={...state};
    switch(action.type)
    {
        case "ADD_USER":{
            var pos=newState.userArr.findIndex(item => item.productId == action.payload.productId)
            if(pos <0)
            {
                newState.userArr.push(action.payload);
            }
            break;
        }
        case "REMOVE_USER":{
            var pos=newState.userArr.findIndex(item => item.productId == action.payload.productId)
            if(pos >=0)
            {
                newState.userArr.splice(pos,1);
            }
            
            break;
        }
    }
    return newState;
}
function cartReducer(state={cartArr:[]},action)
{
    var newState={...state};
    switch(action.type)
    {
        case "ADD_CART_ITEM":{
            var pos=newState.cartArr.findIndex(item => item.productId == action.payload.productId)
            if(pos >=0)
            {
                newState.cartArr[pos].quantitySelected+=action.payload.quantitySelected;
            }
            else
            {
                newState.cartArr.push(action.payload);
            }
            break;
        }
        case "REMOVE_CART_ITEM":{
            var pos=newState.cartArr.findIndex(item => item.productId == action.payload.productId)
            if(pos >=0)
            {
                newState.cartArr.splice(pos,1);
            }
            
            break;
        }
    }
    return newState;
}
function addAction(data)
{
    return {type:"",payload:{}}
}
var myReducer=combineReducers({
    cart:cartReducer,
    user:userReducer
})
var store=createStore(myReducer);

store.subscribe(()=>{
    console.log("State :",store.getState());
})

store.dispatch({type:"ADD_CART_ITEM",payload:
{
    productId:"P101",
    quantitySelected:2
}
})

store.dispatch({type:"ADD_CART_ITEM",payload:
{
    productId:"P101",
    quantitySelected:2
}
})
store.dispatch({type:"ADD_CART_ITEM",payload:
{
    productId:"P102",
    quantitySelected:5
}
})

store.dispatch({type:"REMOVE_CART_ITEM",payload:
{
    productId:"P102",
    
}
})
store.dispatch(addAction(p1)) 
*/