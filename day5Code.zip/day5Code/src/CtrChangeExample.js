import React, { useState,useMemo } from 'react'
import Child from './Child';

export default function CtrChangeExample() {
    var loc=prompt("Enter the location");
    var countNumbers=(ct)=>{
        console.log("Inside the function countNumbers");
        ct+=1000000;
        var sum=0;
        for(let i=0;i<ct;i++)
        {
            sum+=i;
        }
        return sum;
    }
    var cachedValue=useMemo(()=>{
        return countNumbers(100)
    },[]);
    var childCache=useMemo(()=>{
        return(
        <Child></Child>
        )
    },[loc])
  
/*     var ctrArr = useState(0);
    var ctr = ctrArr[0];
    var setCtr = ctrArr[1];
 */
    var [ctr, setCtr] = useState(0);
    var cN="palo Alto"
    console.log("Inside functional component");
    
    //setCtr(100);will result in an infinite loop
    var changeQuantityEventHandler=(op)=>{
        if(op =="dec")
        {
            //setCtr(ctr-1);
            setCtr((prevCtr)=>{
                return prevCtr-1;
            })
        }
        else
        {
           
            setCtr((prevCtr)=>{
                return prevCtr+1;
            })
        }
    }
    return (
        <div>CtrChangeExample
            <div>
                <input type="button" value="-" className='rounded-full p-3 bg-yellow-300' onClick={() => { changeQuantityEventHandler("dec") }} />
                {ctr}
              
                <input type="button" value="+"  className='rounded-full p-3 bg-yellow-300' onClick={() => { changeQuantityEventHandler("inc") }} />
            </div>
            <div>
                <h1> Very Big operation</h1>
             
                <h3> Cached value = {cachedValue}</h3>
            </div>
           {childCache}
        </div>
    )
}
