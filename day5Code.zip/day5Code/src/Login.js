import React, { useState,useContext } from 'react';
import {LoginContext} from "./Main"

export default function Login() {
    
  var loginObj=useContext(LoginContext);
  console.log(loginObj);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loginMessage, setLoginMessage] = useState('');

  const handleUsernameChange = (event) => {
    setUsername(event.target.value);
  };

  const handlePasswordChange = (event) => {
    setPassword(event.target.value);
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    // Perform validation logic here
    if (username === 'admin' && password === 'admin') {
      // Valid credentials
      setLoginMessage('Login successful!');
      //localStorage.setItem("isLoggedIn",true);
      // set the value of isLoggedIn = true;
        loginObj.setIsLoggedIn(true);
    
      // Redirect to another page or perform any other action
    } else {
      // Invalid credentials
      setLoginMessage('Invalid username or password');
      // Display an error message or perform any other action

    
    }
  };

  return (
    <div className="max-w-md mx-auto mt-8 p-6 bg-white rounded shadow-md">
        <h1> login Obj:{JSON.stringify(loginObj)}</h1>
      <h2 className="text-xl font-bold mb-4">Login</h2>
      {loginMessage && <p className="text-red-500 mb-4">{loginMessage}</p>}
      <form onSubmit={handleSubmit}>
        <div className="mb-4">
          <label htmlFor="username" className="block text-gray-700 font-bold mb-2">Username:</label>
          <input
            type="text"
            id="username"
            value={username}
            onChange={handleUsernameChange}
            className="p-2 border border-gray-300 rounded w-full"
          />
        </div>
        <div className="mb-4">
          <label htmlFor="password" className="block text-gray-700 font-bold mb-2">Password:</label>
          <input
            type="password"
            id="password"
            value={password}
            onChange={handlePasswordChange}
            className="p-2 border border-gray-300 rounded w-full"
          />
        </div>
        <button
          type="submit"
          className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
        >
          Login
        </button>
      </form>
    </div>
  );
}

