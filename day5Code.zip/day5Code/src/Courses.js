import React from 'react'
import { Link, Outlet } from 'react-router-dom'

export default function Courses() {
  return (
    <div className='bg-yellow-400'>
        <h1>Courses</h1>
        <h2> Is user logged in {localStorage.getItem("isLoggedIn") ? "Yes" : "No"}</h2>
        <ul>
            <li>
                <Link to="angular">Angular</Link>
            </li>
            <li>
                <Link to="react">React</Link>
            </li>
            <li>
                <Link to="node">Nodejs </Link>
            </li>
        </ul>
        <Outlet></Outlet>
        <h3> Pls enroll to the courses to learn more</h3>
    </div>
  )
}
