import React from 'react'

export default function NodeCourse() {
  return (
    <div className="bg-violet-400 "> 
        NodeCourse</div>
  )
}

