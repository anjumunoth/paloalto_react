var arr1=[10,20,30,40,50];
var sqArr=arr1.map(item => item*item);//[]100,400,900,1600,2500

var empArr=
[{empId:101,empName:"Asha",salary:1001,deptId:"D1"},
{empId:102,empName:"Gaurav",salary:2000,deptId:"D1"},
{empId:103,empName:"Karan",salary:2000,deptId:"D2"},
{empId:104,empName:"Kishan",salary:3000,deptId:"D1"},
{empId:105,empName:"Keshav",salary:3500,deptId:"D2"},
{empId:106,empName:"Pran",salary:4000,deptId:"D3"},
{empId:107,empName:"Saurav",salary:3800,deptId:"D3"}]

var empNameArr=empArr.map(item => item.empName);

var empFilterSalArr=empArr.map(item => {
    if (item.salary > 3000)
        return item;
});

console.log(empFilterSalArr);//

// find -- return the first element

empArr.find(item => {
    if (item.salary ==2000)
    {
        return true;
    }
})

var empWithSal2000=empArr.find(item => (item.salary ==2000));// empId:102 data

var empWithSal200=empArr.find(item => (item.salary ==200));// ud

var empArrWithSal2000=empArr.filter(item => (item.salary ==2000));// empId:102,103 data

var empArrWithSal200=empArr.filter(item => (item.salary ==200));// []

var posOfempWithSal2000=empArr.findIndex(item => (item.salary ==2000));// 1

var posOfempWithSal200=empArr.findIndex(item => (item.salary ==200));// -1


var i=10,j=12,k=15;
i>j ? console.log("i is the greatest"):("j is the greatest")

if((i > j) && (++k> 100))
{
    console.log("true");
}
else
{
    console.log("false");
}
console.log(k);

function myFunc()
{
    console.log("Hello");
    setInterval(()=>{
        console.log("Thank u");
    },1000)
    console.log("bye");
}

myFunc();


function myFunc1(p1,p2)
{
    return p1+p2;

}

function myFunc2(p1,p2)
{
    return p1+p2 + Math.random();
}

/*
Reducer : 
    -- pure function
    -- 2 params
    -- state and action
    -- process the action and modify the state
    -- return the new state

Action
    -- how to modify the state
    -- usually a object
    -- type, payload
    -- type: how to modify the state
    -- payload : optional data required for modifying state
Will not call the reducer directly
dispatch the action


*/

function myFunc3(p1)
{
    var r=setTimeout(()=>{
        if(p1%2 ==0)
            return (`${p1} is an even number`);
        else
            return (`${p1} is an odd number`);
    },1000);
    
        
}

var result=myFunc3(10);
console.log(result);//ud

/*
promise --
-- async function
-- promise states
1. pending -- async op is running
2. resolved / rejected

resolved -- async op is successful; return data
rejected -- async op has failed; return the error

*/

function myFunc4(p1)
{
        if(p1%2 ==0)
            return Promise.resolve(`${p1} is an even number`);
        else
           return Promise.reject(`${p1} is an odd number`);
              
        
}

var myPromise=myFunc4(10);
myPromise
.then((data)=>{
    console.log(data);
    return data.toUpperCase();
})
.then((updata)=>{
    console.log("Updated data",updata)
})
.catch((err)=>{
    console.log(err);
})

function myFunc5(p1)
{
    var evenPromise=new Promise((resolve,reject)=>{
        setTimeout(()=>{
            if(p1%2 ==0)
                resolve(`${p1} is an even number`);
            else
                reject(`${p1} is an odd number`);
        },10000);
    });
    return evenPromise;
}

var myPromise=myFunc5(10);
myPromise
.then((data)=>{
    console.log(data);
    return data.toUpperCase();
})
.then((updata)=>{
    console.log("Updated data",updata)
})
.catch((err)=>{
    console.log(err);
})

function myFunc6(ctr)
{
    return function myFunc7(p1){
        ctr++;
        return ctr+p1;
    }
}

var innerFunc=myFunc6(100);
var res=innerFunc(200);
console.log(res);//301

var res=innerFunc(300);
console.log(res);//402

var res=innerFunc(300);
console.log(res);//403

var res=myFunc6(1000)(1000);