import React, { useReducer ,useEffect,useState} from 'react'
import { userReducer } from "./utils/userReducer";
import axios from "axios";

export default function Users() {
    //useReducer(reducer function, initial state);
    var [loading,setLoading]=useState(true);
    var initialValue = {
        error:{message:""},
        usersArr: []
    }
    var [state,dispatch]=useReducer(userReducer,initialValue);
    
    useEffect(()=>{
        var serverUrl="https://reqres.in/api/users?page=2";
        axios.get(serverUrl)
        .then((response)=>{
            console.log(response.data.data);
            var createUsersArrAction={
                type:"CREATE_USERS_ARR",
                payload:  {data:response.data.data}  
            }
            setLoading(false);
            dispatch(createUsersArrAction);
            
   
        })
        .catch((err)=>{
            console.log(err);
        })
    },[])
    var postRequestEventHandler=()=>{
        var id=parseInt(prompt("Enter the id"));
        var newUser= {
            "email": "michael.lawson@reqres.in",
        "first_name": "Michael",
        "last_name": "Lawson",
        id:id
        };
        var serverUrl="https://reqres.in/api/users";
        axios.post(serverUrl,newUser)
        .then((response)=>{
            console.log("Post req response",response);
            var addAction = {
                type: "ADD_USER",
                payload: { newUser:response.data }
            }
            dispatch(addAction);
        })
        .catch((err)=>{
            console.log("error",err)
        })
    }
    console.log("Users component rendered");
    var userDeleteEventHandler = (selectedUserToDelete) => {
        var deleteAction = {
            type: "DELETE_USER",
            payload: { id: selectedUserToDelete.id }
        }
        dispatch(deleteAction);// implicitly call the reducer function

    }
    var useraddNewEventHandler = () => {
        var id=parseInt(prompt("Enter the id "));
        var newUser = {
            "id": id,
            "email": "michael.lawson@reqres.in",
            "first_name": "Michael",
            "last_name": "Lawson",
            "avatar": "https://reqres.in/img/faces/7-image.jpg"
        };
        var addAction = {
            type: "ADD_USER",
            payload: { newUser }
        }
        dispatch(addAction);

    }
    var userEditEventHandler = (userToBeEdited) => {
        var editAction = {
            type: "EDIT_USER",
            payload:
            {
                newName: userToBeEdited.first_name + userToBeEdited.last_name,
                id: userToBeEdited.id
            }
        }
        dispatch(editAction);
    }
    var trArr = state.usersArr.map(user => {
        return (
            <tr key={user.id} className='text-blue-900'>
                <td>{user.id}</td>
                <td>{user.email}</td>
                <td >{user.first_name}</td>
                <td>
                    <input type="button" value="Delete" onClick={() => { userDeleteEventHandler(user) }} className='bg-blue-700 text-white m-3' />
                    <input type="button" value="Edit" onClick={() => { userEditEventHandler(user) }} className='bg-blue-700 text-white m-3' />
                </td>
            </tr>
        )
    })
    return (
        <div>Users
            
            {loading && <p>Loading data ....</p>}
            <table border="5">
                <thead>
                    <tr>
                        <th>
                            Id
                        </th>
                        <th>
                            Email
                        </th>
                        <th>
                            First Name
                        </th>
                        <th>
                            Actions
                        </th>
                    </tr>
                </thead>
                <tbody>
                    {trArr}
                    <tr>
                        <td>
                            <input type="button" value="Add new user" onClick={useraddNewEventHandler} className='bg-blue-700 text-white m-3' />
                            <input type="button" value="Post request for new user" onClick={postRequestEventHandler} className='bg-blue-700 text-white m-3' />
                        </td>
                    </tr>
                    {state.error?.message != "" && <tr >
                        <td>
                            Error :{state.error.message}
                        </td>
                    </tr>
                    }
                </tbody>
            </table>
        </div>

    )
}
