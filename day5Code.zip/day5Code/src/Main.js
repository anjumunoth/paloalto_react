import React, { createContext, useContext, useState } from 'react'
import { Route, Routes } from "react-router-dom"
import Products from './Products'
import Users from './Users'
import Home from './Home'
import PathNotFound from "./PathNotFound"
import ProductDetails from './ProductDetails'
import Courses from './Courses'
import AngularCourse from './AngularCourse'
import ReactCourse from './ReactCourse'
import NodeCourse from './NodeCourse'
import Login from './Login'
import Register from './Register'
import { AppLoginContext } from './App'
import CtrChangeExample from './CtrChangeExample'
import { Cart } from './Cart'
import CustomHookExample from './CustomHookExample'

export var LoginContext = createContext({});
export default function Main() {
  var appLoginObj = useContext(AppLoginContext);

  return (
    <LoginContext.Provider value={appLoginObj} >
      <div>

        <Routes>
          <Route path="customHookExample" element={<CustomHookExample></CustomHookExample>}></Route>
          <Route path="cart" element={<Cart></Cart>}></Route>
          <Route path="contactus" element={<CtrChangeExample></CtrChangeExample>}></Route>
          <Route path="products" element={<Home></Home>}></Route>
          <Route path="courses" element={<Courses></Courses>}>
            <Route index element={<AngularCourse></AngularCourse>}></Route>
            <Route path="angular" element={<AngularCourse></AngularCourse>}></Route>
            <Route path="react" element={<ReactCourse></ReactCourse>}></Route>
            <Route path="node" element={<NodeCourse></NodeCourse>}></Route>
          </Route>
          <Route path="manageproducts" element={<Products></Products>}></Route>
          <Route path="users" element={<Users></Users>}></Route>
          <Route path="login" element={<Login></Login>}></Route>
          <Route path="register" element={<Register></Register>}></Route>
          <Route path="/" element={<Home></Home>}></Route>
          <Route path="*" element={<PathNotFound></PathNotFound>}></Route>
          <Route path="productDetails/:pId" element={<ProductDetails></ProductDetails>}></Route>
        </Routes>

      </div>
    </LoginContext.Provider>
  )
}
