import React from 'react'

export default function PathNotFound() {
  return (
    <h1>PathNotFound</h1>
  )
}
