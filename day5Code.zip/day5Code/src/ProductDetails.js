import React from 'react'
import {useLocation,useParams,useNavigate,useHref} from "react-router-dom"

export default function ProductDetails() {
    var location=useLocation();
    console.log("Locattion",location);
    var navigate=useNavigate();
    var params=useParams();
    var match=useHref();
    console.log("Match",match);
    var backEventHandler=()=>{
        navigate("/manageproducts");
    }
  return (
    <div>
        <h1>ProductDetails</h1>
        <h2> Product Id : {params.pId}</h2>
        <p>Product Details : {JSON.stringify(location.state.selectedProduct)}</p>
        <input type="button" value="Back" className='rounded-full p-3 bg-blue-300 m-3' onClick={()=>{backEventHandler()}}/>               
    </div>
  )
}
