import React, { createContext, useState } from 'react'
import { BrowserRouter } from 'react-router-dom';
import { Provider } from 'react-redux';
import './App.css';
import Menu from "./Menu";
import Footer from './Footer';
import { Cart } from './Cart';

import Header from "./Header";
import Main from './Main';
import {store} from "./store/store.js"


export var AppLoginContext = createContext({});
function App() {
  var companyName = "Palo Alto";
  var emp = { empId: 101, empname: "sara" }
  var [isLoggedIn, setIsLoggedIn] = useState(false);
  return (
    <div>
      <Provider store={store}>
        <AppLoginContext.Provider value={{ "isLoggedIn": isLoggedIn, setIsLoggedIn }} >
          <Header></Header>
          <BrowserRouter>
            <Menu></Menu>
            <Main></Main>
          </BrowserRouter>


          <Footer></Footer>
        </AppLoginContext.Provider>
      </Provider>
    </div>
  );
}

export default App;
