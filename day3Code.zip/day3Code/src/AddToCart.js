import React, { Component } from 'react'

export default class AddToCart extends Component {
    constructor(props)
    {
        super(props);
        alert("Constructor of AddToCart called")
        this.state={quantitySelected:1,selectedProduct:this.props.selectedProduct}
    }
    static getDerivedStateFromProps(newProps,prevState)
    {
        if(newProps.selectedProduct.productId == prevState.selectedProduct.productId)
        {
            return prevState;
        }
        else
        {
            return {...prevState,quantitySelected:1,selectedProduct:newProps.selectedProduct}
        }
    }
    changeQuantityEventHandler=(op)=>{
        if(op=="inc")
        {
            if(this.state.quantitySelected < this.props.selectedProduct.quantity)
            {
                this.setState((prevState)=>{
                    return (
                        {
                            quantitySelected:prevState.quantitySelected+1
                        }
                    )
                })
            }
        }
        else
        {
            if(this.state.quantitySelected >1)
            {
                this.setState((prevState)=>{
                    return (
                        {
                            quantitySelected:prevState.quantitySelected-1
                        }
                    )
                })
            }
        }
    }
    cancelEventHandler=()=>{
        // trigger the event
        this.props.onCancelConfirmation();
    }
    confirmEventHandler=()=>{
        var cartObj={...this.state.selectedProduct,quantitySelected:this.state.quantitySelected};
        // AddToCart has to be unmounted
        this.props.onAddToCartConfirmation(cartObj);
        // product has to be added to the cart
        //update the quantity in parent
    }
  render() {
    var product=this.props.selectedProduct;
    return (
      <div>AddToCart
        <p> Location : {this.props.data}</p>
        <p> ProductDetails: {JSON.stringify(this.props.selectedProduct)}</p>
        <div className=' card grid grid-cols-1 bg-purple-200 place-items-center'>
                    <div className='col-span-1'>
                        <img src={product.imgUrl} />
                    </div>
                    <div>
                        <h1>{product.productName}</h1>
                        <p>Price :{product.price}</p>
                        <p>Quantity :{product.quantity}</p>

                    </div>
                    <div>
                        <input type="button" value="-" disabled={this.state.quantitySelected<=1} className='rounded-full p-3 bg-yellow-300' onClick={()=>{this.changeQuantityEventHandler("dec")}}/>
                        {this.state.quantitySelected}
                        <input type="button" value="+" disabled={this.state.quantitySelected >=this.props.selectedProduct.quantity} className='rounded-full p-3 bg-yellow-300'onClick={()=>{this.changeQuantityEventHandler("inc")}}/>
                    </div>
                    <div>
                    <input type="button" value="Confirm" className='rounded-full p-3 bg-green-500' onClick={this.confirmEventHandler}/>
                    <input type="button" value="Cancel" className='rounded-full p-3 bg-red-500' onClick={this.cancelEventHandler}/>
                    </div>
                    
                </div>

      </div>
    )
  }
}
