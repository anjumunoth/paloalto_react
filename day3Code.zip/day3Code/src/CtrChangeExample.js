import React, { useState } from 'react'

export default function CtrChangeExample() {
/*     var ctrArr = useState(0);
    var ctr = ctrArr[0];
    var setCtr = ctrArr[1];
 */
    var [ctr, setCtr] = useState(0);
    var cN="palo Alto"
    console.log("Inside functional component");
    //setCtr(100);will result in an infinite loop
    var changeQuantityEventHandler=(op)=>{
        if(op =="dec")
        {
            //setCtr(ctr-1);
            setCtr((prevCtr)=>{
                return prevCtr-1;
            })
        }
        else
        {
            cN="jj";
            console.log("Value of cn"+ cN);
            setCtr((prevCtr)=>{
                return prevCtr+1;
            })
        }
    }
    return (
        <div>CtrChangeExample
            <div>
                <input type="button" value="-" className='rounded-full p-3 bg-yellow-300' onClick={() => { changeQuantityEventHandler("dec") }} />
                {ctr}
                {cN}
                <input type="button" value="+"  className='rounded-full p-3 bg-yellow-300' onClick={() => { changeQuantityEventHandler("inc") }} />
            </div>

        </div>
    )
}
