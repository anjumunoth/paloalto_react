
import './App.css';
import {Cart} from './Cart';
import {ContactUs} from './Cart';
import Clock from './Clock';
import flower from "./flower.jpg"
import Header from "./Header";
import Home from './Home';
import CtrChangeExample from "./CtrChangeExample"
import EffectExamples from './EffectExamples';
import Products from './Products';


function App() {
  var companyName = "Palo Alto";
  var emp = { empId: 101, empname: "sara" }
  return (
    <div>
      <Products></Products>
     {/*  <Clock></Clock>
      <Header></Header>
      <CtrChangeExample></CtrChangeExample>
      <Home></Home>
      <Cart></Cart>
      <ContactUs></ContactUs>
            <EffectExamples></EffectExamples> */}
    </div>
  );
}

export default App;
