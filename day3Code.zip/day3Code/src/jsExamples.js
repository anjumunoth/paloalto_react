var arr1=[10,20,30,40,50];
var sqArr=arr1.map(item => item*item);//[]100,400,900,1600,2500

var empArr=
[{empId:101,empName:"Asha",salary:1001,deptId:"D1"},
{empId:102,empName:"Gaurav",salary:2000,deptId:"D1"},
{empId:103,empName:"Karan",salary:2000,deptId:"D2"},
{empId:104,empName:"Kishan",salary:3000,deptId:"D1"},
{empId:105,empName:"Keshav",salary:3500,deptId:"D2"},
{empId:106,empName:"Pran",salary:4000,deptId:"D3"},
{empId:107,empName:"Saurav",salary:3800,deptId:"D3"}]

var empNameArr=empArr.map(item => item.empName);

var empFilterSalArr=empArr.map(item => {
    if (item.salary > 3000)
        return item;
});

console.log(empFilterSalArr);//

// find -- return the first element

empArr.find(item => {
    if (item.salary ==2000)
    {
        return true;
    }
})

var empWithSal2000=empArr.find(item => (item.salary ==2000));// empId:102 data

var empWithSal200=empArr.find(item => (item.salary ==200));// ud

var empArrWithSal2000=empArr.filter(item => (item.salary ==2000));// empId:102,103 data

var empArrWithSal200=empArr.filter(item => (item.salary ==200));// []

var posOfempWithSal2000=empArr.findIndex(item => (item.salary ==2000));// 1

var posOfempWithSal200=empArr.findIndex(item => (item.salary ==200));// -1
