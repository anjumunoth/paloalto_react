import React, { Component } from 'react'

export default class extends Component {
    constructor()
    {
        super();
        this.state={now:new Date(),clearIntervalId:null}
    }
    componentDidMount()
    {
        var intervalId=setInterval(()=>{
            this.setState({now:new Date()})
        },1000);
        this.setState({clearIntervalId:intervalId})
        
    }
    componentWillUnmount()
    {
        //stop the interval
        clearInterval(this.state.clearIntervalId);
    }
  render() {

    return (
      <div> {this.state.now.getHours() }:{ this.state.now.getMinutes()}:{this.state.now.getSeconds() }</div>
    )
  }
}
