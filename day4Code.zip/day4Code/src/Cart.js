import React,{useState} from 'react'

export function Cart(props)
{
    return (
        <h1>Cart Component</h1>
    )
}

export function ContactUs(props)
{
    return (
        <h1>Contact Us Component</h1>
    )
}