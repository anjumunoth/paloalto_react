import React from 'react'
import {Route,Routes} from "react-router-dom"
import Products from './Products'
import Users from './Users'
import Home from './Home'
import PathNotFound from "./PathNotFound"
import ProductDetails from './ProductDetails'

export default function Main() {
  return (
    <div>
        <Routes>
            <Route path="products" element={<Home></Home>}></Route>
            <Route path="manageproducts" element={<Products></Products>}></Route>
            <Route path="users" element={<Users></Users>}></Route>
            <Route path="/" element={<Home></Home>}></Route>
            <Route path="*" element={<PathNotFound></PathNotFound>}></Route>
            <Route path="productDetails/:pId" element={<ProductDetails></ProductDetails>}></Route>
        </Routes>
    </div>
  )
}
