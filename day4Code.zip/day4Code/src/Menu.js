import React from 'react'
import { Link } from 'react-router-dom'
import "./Menu.css";

export default function Menu() {
    return (
        <div>
            <ul>
                <li>
                    <Link to="products">Products</Link>
                </li>
                <li>
                    <Link to="users">Users</Link>
                </li>
                <li>
                    <Link to="manageproducts">Manage Products</Link>
                </li>
                <li>
                    <Link to="register">Sign In</Link>
                </li>
                <li>
                    <Link to="login">Login</Link>
                </li>
                <li>
                    <Link to="contactus">Contact Us</Link>
                </li>
                <li>
                    <Link to="aboutus">About Us</Link>
                </li>
            </ul>
        </div>
    )
}
