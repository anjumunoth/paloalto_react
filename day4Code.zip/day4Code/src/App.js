
import './App.css';
import Menu from "./Menu";
import Footer from './Footer';
import {Cart} from './Cart';
import {ContactUs} from './Cart';
import Clock from './Clock';
import flower from "./flower.jpg"
import Header from "./Header";
import Home from './Home';
import CtrChangeExample from "./CtrChangeExample"
import EffectExamples from './EffectExamples';
import Products from './Products';
import Users from "./Users"
import { BrowserRouter } from 'react-router-dom';
import Main from './Main';


function App() {
  var companyName = "Palo Alto";
  var emp = { empId: 101, empname: "sara" }
  return (
    <div>
      <Header></Header>
      <BrowserRouter>
          <Menu></Menu>
          <Main></Main>
      </BrowserRouter>
     
      
      <Footer></Footer>
     </div>
  );
}

export default App;
